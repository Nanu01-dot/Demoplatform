# DEMO-PLATFORM: Step-by-Step Mentor Guide

Project = 1 parent Maven project + 3 Spring Boot "items" (modules):
| Module | Port | URL | K8s NodePort |
|---|---|---|---|
| product-service | 8081 | /api/product | 30081 |
| order-service | 8082 | /api/order | 30082 |
| user-service | 8083 | /api/user | 30083 |

Replace everywhere: YOUR_GITHUB_USER, YOUR_DOCKERHUB_USER.

---
## PART 1 - Install tools (once)
Check each in a terminal:
```
java -version      # 17+
mvn -version
git --version
docker --version
kubectl version --client
```
For local Kubernetes: Docker Desktop (Settings > Kubernetes > Enable) OR `minikube start`.

## PART 2 - Run this project
```
cd demo-platform
mvn clean package
java -jar product-service/target/product-service.jar
```
Open http://localhost:8081/api/product -> "Hello from product-service!"

## PART 3 - Create the same project MANUALLY in Eclipse
1. Eclipse > File > New > Maven Project > tick "Create a simple project (skip archetype)" > Next.
2. Group Id `com.example`, Artifact Id `demo-platform`, Version `1.0.0`, **Packaging = pom** > Finish.
3. Open pom.xml. Paste the parent section (spring-boot-starter-parent 3.2.5), java.version 17 (copy from this project's pom.xml).
4. Right-click project > New > Other > Maven > **Maven Module** > tick "Create simple project" > Module name `product-service` > Finish. Repeat for `order-service`, `user-service`.
5. In each module's pom.xml add dependencies: spring-boot-starter-web, spring-boot-starter-actuator, spring-boot-starter-test (test scope), plus spring-boot-maven-plugin in build (copy from this project). Add `<finalName>product-service</finalName>`.
6. In each module: New > Class, package `com.example.product`, name `ProductServiceApplication` with `@SpringBootApplication` and `main()`. Add a `@RestController` class returning a string.
7. Create `src/main/resources/application.properties` with `server.port=8081` (8082, 8083 for others).
8. Right-click project > Maven > Update Project (Alt+F5).
9. Run: right-click ProductServiceApplication > Run As > Java Application.
10. Build jars: right-click parent > Run As > Maven build... > Goals `clean package` > Run.
Import this project instead: File > Import > Maven > Existing Maven Projects > select the demo-platform folder.

## PART 4 - Docker (local test)
```
mvn clean package -DskipTests
docker build -t YOUR_DOCKERHUB_USER/product-service:1.0 product-service
docker run -d -p 8081:8081 YOUR_DOCKERHUB_USER/product-service:1.0
curl localhost:8081/api/product
```
All three at once: `docker compose up --build`
Push: `docker login` then `docker push YOUR_DOCKERHUB_USER/product-service:1.0`

## PART 5 - Kubernetes (local test)
```
sed -e "s|DOCKERHUB_USER|YOUR_DOCKERHUB_USER|g" -e "s|IMAGE_TAG|latest|g" product-service/k8s/deployment.yaml | kubectl apply -f -
kubectl apply -f product-service/k8s/service.yaml
kubectl get pods
kubectl get svc
```
Docker Desktop: http://localhost:30081/api/product
Minikube: `minikube service product-service --url`
Repeat for the other two services.

## PART 6 - Push code to GitHub
```
cd demo-platform
git init && git add . && git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USER/demo-platform.git
git push -u origin main
```

## PART 7 - Jenkins health check (do this BEFORE jobs)
I can't see inside your Jenkins from here, so check this list yourself:
1. Version: Manage Jenkins > About. Use latest LTS (Java 17 or 21).
2. Plugins (Manage Jenkins > Plugins > Installed): Git, Pipeline, Credentials Binding, Docker Pipeline, Pipeline: Stage View, Workspace Cleanup. Update anything with an update badge.
3. Tools (Manage Jenkins > Tools): add JDK named `JDK17` and Maven named `Maven3` (Install automatically).
4. Docker on the Jenkins machine: `sudo usermod -aG docker jenkins && sudo systemctl restart jenkins`, then in a Jenkins shell step `docker ps` must work.
5. kubectl installed on the Jenkins machine; `sudo -u jenkins kubectl version --client` must work.
6. Disk space > 10 GB free; Manage Jenkins > System Information.
7. Security: Manage Jenkins > Security: enable login, no "anyone can do anything". Never use admin/admin.
8. Backup: install "ThinBackup" plugin or back up /var/lib/jenkins.
9. Manage Jenkins shows no red warnings. Fix each one.
Send me screenshots of Plugins list, Tools page and warnings, and I'll review them.

## PART 8 - Jenkins credentials
Manage Jenkins > Credentials > System > Global credentials > Add Credentials.

| ID (exact) | Kind | What to enter |
|---|---|---|
| github-creds | Username with password | GitHub username + **Personal Access Token** (GitHub > Settings > Developer settings > Tokens, scope `repo`). NOT your password. |
| dockerhub-creds | Username with password | Docker Hub username + Access Token (Docker Hub > Account Settings > Security > New Access Token, Read/Write) |
| kubeconfig | Secret file | Upload your ~/.kube/config file |

The IDs must match what the Jenkinsfiles use.
Minikube/Docker Desktop kubeconfig points to localhost; works if Jenkins runs on the same machine. Otherwise use a cloud cluster kubeconfig.

## PART 9 - Create the 3 Jenkins items
For each: Dashboard > New Item > name > **Pipeline** > OK.
Scroll to Pipeline section > Definition: **Pipeline script from SCM** > SCM: Git > Repo URL, Credentials `github-creds`, Branch `*/main` > Script Path as below > Save.

| # | Item name | Script Path |
|---|---|---|
| 1 | demo-1-checkout | jenkins/Jenkinsfile.checkout |
| 2 | demo-2-image | jenkins/Jenkinsfile.image |
| 3 | demo-3-deploy | jenkins/Jenkinsfile.deploy |

Also tick "This project is parameterized" is NOT needed (Jenkinsfile declares IMAGE_TAG; run job once first so the Build with Parameters button appears).

Run order: demo-1-checkout (auto-triggers demo-2-image) > then demo-3-deploy with the IMAGE_TAG (git short SHA shown in image job, or `latest`).

## PART 10 - One full pipeline (alternative)
New Item > `demo-full-pipeline` > Pipeline > Pipeline script from SCM > Script Path `Jenkinsfile` (the root file). One click does checkout > build > images > deploy.

Auto-trigger on push: GitHub repo > Settings > Webhooks > `http://YOUR_JENKINS_URL/github-webhook/`, and in the job tick "GitHub hook trigger for GITScm polling" (needs the GitHub plugin and a public Jenkins URL).

## PART 11 - Verify
```
kubectl get pods
curl http://localhost:30081/api/product
curl http://localhost:30082/api/order
curl http://localhost:30083/api/user
```

## Common errors
- `docker: permission denied` > Part 7 step 4.
- `kubectl: command not found` > install kubectl on Jenkins machine.
- `No such tool Maven3` > Part 7 step 3 names must match exactly.
- `ImagePullBackOff` > wrong DOCKERHUB_USER or image not pushed (or private repo).
- `Authentication failed` for Git > use token, not password.
- Pod stuck not ready > `kubectl logs <pod>` and `kubectl describe pod <pod>`.
